#ifndef __BLWIFI_H__
#define __BLWIFI_H__

//#define SUPPORT_DEBUG
//#define RESET_WIFI_PIN    12
//#define RELAY_PIN         4
//#define LED_IO 15

struct Settings 
{
  char auth_key[13];
  char ssid[128];
  char pswd[32];
};
extern Settings wifiSettings;

void Blwifi_InitWiFi();
void ClearWiFiInfo();
void ResetWifi();

#endif
